const timeService = require('../services/timeService');
const db = require('../db');

async function clockIn(req, res) {
  try {
    const { type } = req.body || {};
    const userId = req.user && req.user.id;
    if (!userId) return res.status(401).json({ error: 'Unauthorized' });
    const created = await timeService.createEntry(userId, type);
    return res.status(201).json(created);
  } catch (err) {
    const status = err && err.status ? err.status : 500;
    return res.status(status).json({ error: err.message || 'Server error' });
  }
}

async function history(req, res) {
  try {
    const userId = req.user && req.user.id;
    if (!userId) return res.status(401).json({ error: 'Unauthorized' });
    const { startDate, endDate } = req.query || {};
    let sql = 'SELECT id, timestamp, type FROM "TimeEntry" WHERE userId = ?';
    const params = [userId];
    if (startDate && endDate) {
      sql += ' AND timestamp BETWEEN ? AND ?';
      params.push(startDate, endDate);
    } else if (startDate) {
      sql += ' AND timestamp >= ?';
      params.push(startDate);
    } else if (endDate) {
      sql += ' AND timestamp <= ?';
      params.push(endDate);
    }
    sql += ' ORDER BY timestamp ASC';
    const rows = db.all(sql, params);
    return res.json(rows);
  } catch (err) {
    return res.status(500).json({ error: 'Server error' });
  }
}

module.exports = { clockIn, history };
