const bcrypt = require('bcryptjs');
const db = require('../db');

async function listUsers(req, res) {
  const users = db.all('SELECT id, name, email, role FROM "User"');
  res.json(users);
}

async function createUser(req, res) {
  const { name, email, password, role } = req.body || {};
  if (!name || !email || !password) return res.status(400).json({ error: 'Missing fields' });
  const existing = db.get('SELECT id FROM "User" WHERE email = ?', [email]);
  if (existing) return res.status(409).json({ error: 'User exists' });
  const hash = await bcrypt.hash(password, 10);
  db.createUser({ name, email, password: hash, role: role || 'USER' });
  return res.status(201).json({ message: 'created' });
}

async function updateUser(req, res) {
  const id = Number(req.params.id);
  const { name, email, password, role } = req.body || {};
  const user = db.get('SELECT * FROM "User" WHERE id = ?', [id]);
  if (!user) return res.status(404).json({ error: 'Not found' });
  const updates = [];
  const params = [];
  if (name) { updates.push('name = ?'); params.push(name); }
  if (email) { updates.push('email = ?'); params.push(email); }
  if (role) { updates.push('role = ?'); params.push(role); }
  if (password) { const hash = await bcrypt.hash(password, 10); updates.push('password = ?'); params.push(hash); }
  if (updates.length === 0) return res.status(400).json({ error: 'No updates' });
  params.push(id);
  db.run(`UPDATE "User" SET ${updates.join(', ')} WHERE id = ?`, params);
  return res.json({ message: 'updated' });
}

async function deleteUser(req, res) {
  const id = Number(req.params.id);
  const user = db.get('SELECT * FROM "User" WHERE id = ?', [id]);
  if (!user) return res.status(404).json({ error: 'Not found' });
  db.run('DELETE FROM "User" WHERE id = ?', [id]);
  return res.json({ message: 'deleted' });
}

module.exports = { listUsers, createUser, updateUser, deleteUser };
