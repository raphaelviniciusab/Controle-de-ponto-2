import React, { useState } from 'react';
import api from '../services/api';
import { format } from 'date-fns';
import Input from '../ui/Input';
import Button from '../ui/Button';
import Card from '../ui/Card';

function formatLabel(type){
  switch(type){
    case 'IN': return 'Entrada';
    case 'PAUSE': return 'Pausa';
    case 'RETURN': return 'Retorno';
    case 'OUT': return 'Saída';
    default: return type;
  }
}

function msToHoursMinutes(ms){
  const totalMinutes = Math.floor(ms / 60000);
  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;
  return `${hours}h ${minutes}m`;
}

export default function History(){
  const today = new Date().toISOString().slice(0,10);
  const [startDate, setStartDate] = useState(today);
  const [endDate, setEndDate] = useState(today);
  const [entries, setEntries] = useState([]);
  const [loading, setLoading] = useState(false);
  const [totalMs, setTotalMs] = useState(0);

  function computeTotalHours(list){
    if(!list || list.length === 0) return 0;
    // ensure sorted by createdAt asc
    const sorted = [...list].sort((a,b)=> new Date(a.createdAt || a.created_at) - new Date(b.createdAt || b.created_at));
    let total = 0;
    for(let i=0;i<sorted.length-1;i++){
      const a = sorted[i];
      const b = sorted[i+1];
      const aType = (a.type || a.typeName || '').toUpperCase();
      const bType = (b.type || b.typeName || '').toUpperCase();
      const startTypes = ['IN','RETURN'];
      const endTypes = ['PAUSE','OUT'];
      if(startTypes.includes(aType) && endTypes.includes(bType)){
        const tA = new Date(a.createdAt || a.created_at);
        const tB = new Date(b.createdAt || b.created_at);
        if(!isNaN(tA) && !isNaN(tB) && tB > tA){
          total += (tB - tA);
        }
      }
    }
    return total;
  }

  async function handleSearch(e){
    e && e.preventDefault();
    setLoading(true);
    try{
      const res = await api.get('/time/history', { params: { startDate, endDate } });
      const data = res.data || [];
      setEntries(data);
      const total = computeTotalHours(data);
      setTotalMs(total);
    }catch(err){
      console.error('Failed to fetch history', err);
      alert(err?.response?.data?.message || 'Erro ao buscar histórico');
    }finally{
      setLoading(false);
    }
  }

  return (
    <div className="max-w-4xl mx-auto">
      <header className="my-6">
        <h2 className="text-2xl font-bold">Meu Histórico de Pontos</h2>
        <p className="text-sm text-gray-600">Visualize seus registros e o total de horas trabalhadas no período.</p>
      </header>

      <Card className="mb-6">
        <form onSubmit={handleSearch} className="grid grid-cols-3 gap-4 items-end">
          <Input label="Data de Início" type="date" value={startDate} onChange={e=>setStartDate(e.target.value)} />
          <Input label="Data de Fim" type="date" value={endDate} onChange={e=>setEndDate(e.target.value)} />
          <div>
            <Button variant="primary" type="submit" className="w-full" disabled={loading}>{loading ? 'Buscando...' : 'Buscar'}</Button>
          </div>
        </form>

        <div className="mt-4 text-right">
          <div className="text-sm text-gray-500">Total trabalhado</div>
          <div className="text-xl font-semibold">{msToHoursMinutes(totalMs)}</div>
        </div>
      </Card>

      <Card>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500">Data</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500">Horário</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500">Tipo</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y">
              {entries.length === 0 && (
                <tr><td colSpan="3" className="px-6 py-4 text-gray-500">Nenhum registro encontrado para o período.</td></tr>
              )}
              {entries.map((e, idx)=>{
                const dt = new Date(e.createdAt || e.created_at || e.date || e.timestamp);
                const dateStr = isNaN(dt) ? '-' : format(dt, 'yyyy-MM-dd');
                const timeStr = isNaN(dt) ? '-' : format(dt, 'HH:mm:ss');
                return (
                  <tr key={idx}>
                    <td className="px-6 py-3 whitespace-nowrap">{dateStr}</td>
                    <td className="px-6 py-3 whitespace-nowrap">{timeStr}</td>
                    <td className="px-6 py-3 whitespace-nowrap">{formatLabel(e.type || e.typeName || e.type)}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}
import React from 'react';

export default function History(){
  return (
    <div className="p-4">
      <h2 className="text-xl font-semibold">History</h2>
    </div>
  );
}
