import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import Card from '../ui/Card';
import Input from '../ui/Input';
import Button from '../ui/Button';

export default function Login(){
  const navigate = useNavigate();
  const { login } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e){
    e.preventDefault();
    setLoading(true);
    try{
      await login(email, password);
      navigate('/');
    }catch(err){
      console.error('Login failed', err);
      alert(err?.response?.data?.message || 'Falha no login');
    }finally{
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <div className="w-full max-w-md">
        <Card>
          <h1 className="text-2xl font-bold mb-4">Entrar</h1>
          <form onSubmit={handleSubmit} className="space-y-4">
            <Input label="E-mail" type="email" value={email} onChange={e=>setEmail(e.target.value)} />
            <Input label="Senha" type="password" value={password} onChange={e=>setPassword(e.target.value)} />
            <div className="pt-2">
              <Button variant="primary" type="submit" className="w-full" disabled={loading}>{loading ? 'Entrando...' : 'Entrar'}</Button>
            </div>
          </form>
        </Card>
      </div>
    </div>
  );
}
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../services/api';

export default function Login(){
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  async function handleSubmit(e){
    e.preventDefault();
    setError(null);
    try{
      await api.post('/auth/login', { email, password });
      navigate('/');
    }catch(err){
      setError('Credenciais inválidas');
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <form onSubmit={handleSubmit} className="bg-white p-6 rounded shadow-md w-80">
        <h2 className="text-xl font-semibold mb-4">Entrar</h2>
        {error && <div className="text-red-600 mb-2">{error}</div>}
        <label className="block text-sm mb-1">Email</label>
        <input className="w-full border px-3 py-2 mb-3 rounded" value={email} onChange={(e)=>setEmail(e.target.value)} />
        <label className="block text-sm mb-1">Senha</label>
        <input type="password" className="w-full border px-3 py-2 mb-4 rounded" value={password} onChange={(e)=>setPassword(e.target.value)} />
        <button type="submit" className="w-full bg-blue-600 text-white py-2 rounded">Entrar</button>
      </form>
    </div>
  );
}
