import React, { useEffect, useState } from 'react';
import ClockButton from '../components/ClockButton';
import { useAuth } from '../context/AuthContext';
import api from '../services/api';
import Button from '../ui/Button';
import Card from '../ui/Card';

function formatLabel(type){
  switch(type){
    case 'IN': return 'Entrada';
    case 'PAUSE': return 'Pausa';
    case 'RETURN': return 'Retorno';
    case 'OUT': return 'Saída';
    default: return type;
  }
}

export default function Clock(){
  const { user } = useAuth();
  const [todaysEntries, setTodaysEntries] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(()=>{
    fetchToday();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function fetchToday(){
    try{
      const res = await api.get('/time/history');
      const data = res.data || [];
      const start = new Date();
      start.setHours(0,0,0,0);
      const end = new Date();
      end.setHours(23,59,59,999);

      const filtered = data.filter(e => {
        const t = new Date(e.createdAt || e.created_at || e.date || e.timestamp);
        return t >= start && t <= end;
      }).sort((a,b)=> new Date(a.createdAt || a.created_at) - new Date(b.createdAt || b.created_at));

      setTodaysEntries(filtered);
    }catch(err){
      console.error('Failed to fetch today entries', err);
    }
  }

  async function handleClock(type){
    setLoading(true);
    try{
      await api.post('/time/clock-in', { type });
      await fetchToday();
    }catch(err){
      console.error('Clock-in failed', err);
      alert(err?.response?.data?.message || 'Erro ao registrar ponto');
    }finally{
      setLoading(false);
    }
  }

  const last = todaysEntries.length ? todaysEntries[todaysEntries.length - 1] : null;
  const lastType = last ? (last.type || last.typeName || last.type) : null;

  const enabled = {
    IN: false,
    PAUSE: false,
    RETURN: false,
    OUT: false
  };

  if(!lastType){
    enabled.IN = true;
  } else if(lastType === 'IN'){
    enabled.PAUSE = true;
    enabled.OUT = true;
  } else if(lastType === 'PAUSE'){
    enabled.RETURN = true;
  } else if(lastType === 'RETURN'){
    enabled.PAUSE = true;
    enabled.OUT = true;
  }

  return (
    <div className="max-w-3xl mx-auto">
      <header className="my-6">
        <h2 className="text-2xl font-bold">Olá, {user?.name || user?.email || 'Usuário'}!</h2>
        <p className="text-sm text-gray-600">Registre suas entradas e saídas do dia</p>
      </header>

      <Card className="mb-6">
        <div className="grid grid-cols-2 gap-4">
          <ClockButton type="IN" label="Entrada" onClick={()=>handleClock('IN')} disabled={!enabled.IN || loading} />
          <ClockButton type="PAUSE" label="Pausa" onClick={()=>handleClock('PAUSE')} disabled={!enabled.PAUSE || loading} />
          <ClockButton type="RETURN" label="Retorno" onClick={()=>handleClock('RETURN')} disabled={!enabled.RETURN || loading} />
          <ClockButton type="OUT" label="Saída" onClick={()=>handleClock('OUT')} disabled={!enabled.OUT || loading} />
        </div>
        <div className="mt-4 flex justify-end">
          <Button variant="neutral" onClick={fetchToday}>Atualizar</Button>
        </div>
      </Card>

      <section>
        <h3 className="text-lg font-semibold mb-2">Registros de hoje</h3>
        {todaysEntries.length === 0 && <p className="text-sm text-gray-500">Nenhum registro ainda.</p>}
        <ul className="space-y-2">
          {todaysEntries.map((e, idx)=>{
            const time = new Date(e.createdAt || e.created_at || e.date || e.timestamp).toLocaleTimeString();
            return (
              <li key={idx} className="flex justify-between bg-white p-3 rounded shadow-sm">
                <div className="font-medium">{formatLabel(e.type || e.typeName || e.type)}</div>
                <div className="text-sm text-gray-600">{time}</div>
              </li>
            );
          })}
        </ul>
      </section>
    </div>
  );
}
import React from 'react';

export default function Clock(){
  return (
    <div className="p-4">
      <h2 className="text-xl font-semibold">Clock</h2>
    </div>
  );
}
