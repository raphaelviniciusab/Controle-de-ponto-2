import React, { useEffect, useState } from 'react';
import api from '../services/api';
import Card from '../ui/Card';
import Button from '../ui/Button';

export default function Admin(){
  const [users, setUsers] = useState([]);
  const [userId, setUserId] = useState('');
  const [startDate, setStartDate] = useState(new Date().toISOString().slice(0,10));
  const [endDate, setEndDate] = useState(new Date().toISOString().slice(0,10));
  const [loading, setLoading] = useState(false);

  useEffect(()=>{
    loadUsers();
  }, []);

  async function loadUsers(){
    try{
      const res = await api.get('/users');
      setUsers(res.data || []);
      if(res.data && res.data.length) setUserId(res.data[0].id || res.data[0].userId || res.data[0].id.toString());
    }catch(err){
      console.error('Failed to load users', err);
    }
  }

  async function handleExport(e){
    e.preventDefault();
    if(!userId){
      alert('Selecione um usuário');
      return;
    }
    setLoading(true);
    try{
      const res = await api.get('/reports/csv', {
        params: { userId, startDate, endDate },
        responseType: 'blob'
      });
      const blob = new Blob([res.data], { type: 'text/csv' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `report-${userId}-${startDate}_to_${endDate}.csv`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      window.URL.revokeObjectURL(url);
    }catch(err){
      console.error('Export failed', err);
      alert('Erro ao exportar CSV');
    }finally{
      setLoading(false);
    }
  }

  return (
    <div className="max-w-4xl mx-auto">
      <header className="my-6">
        <h2 className="text-2xl font-bold">Painel do Administrador</h2>
        <p className="text-sm text-gray-600">Exportar relatórios por usuário e intervalo de datas.</p>
      </header>

      <Card>
        <form onSubmit={handleExport} className="space-y-4">
          <div>
            <label className="block text-sm text-gray-700">Usuário</label>
            <select className="mt-1 p-2 border rounded w-full" value={userId} onChange={e=>setUserId(e.target.value)}>
              <option value="">-- selecione --</option>
              {users.map(u=> (
                <option key={u.id} value={u.id}>{u.name || u.email || u.id}</option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm text-gray-700">Data de Início</label>
              <input type="date" value={startDate} onChange={e=>setStartDate(e.target.value)} className="mt-1 p-2 border rounded w-full" />
            </div>
            <div>
              <label className="block text-sm text-gray-700">Data de Fim</label>
              <input type="date" value={endDate} onChange={e=>setEndDate(e.target.value)} className="mt-1 p-2 border rounded w-full" />
            </div>
          </div>

          <div className="flex items-center">
            <Button variant="primary" type="submit" disabled={loading}>{loading ? 'Exportando...' : 'Exportar CSV'}</Button>
          </div>
        </form>
      </Card>
    </div>
  );
}
