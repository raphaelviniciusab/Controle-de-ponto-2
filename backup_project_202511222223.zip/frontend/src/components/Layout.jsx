import React from 'react';
import { Link, Outlet, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import Button from '../ui/Button';

export default function Layout(){
  const { logout, user } = useAuth();
  const navigate = useNavigate();

  async function handleLogout(){
    await logout();
    navigate('/login');
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between">
          <h1 className="text-lg font-bold">Controle de Ponto</h1>
          <nav className="flex items-center">
            <Link to="/" className="mr-4 text-sm text-blue-600">Clock</Link>
            <Link to="/history" className="mr-4 text-sm text-gray-700">History</Link>
            {user?.role === 'ADMIN' && (
              <Link to="/admin" className="mr-4 text-sm text-indigo-600">Admin</Link>
            )}
            {user && <Button variant="danger" onClick={handleLogout} className="text-sm">Logout</Button>}
          </nav>
        </div>
      </header>
      <main className="container mx-auto p-4">
        <Outlet />
      </main>
    </div>
  );
}
