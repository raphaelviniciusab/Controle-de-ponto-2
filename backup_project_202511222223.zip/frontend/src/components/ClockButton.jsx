import React from 'react';

function Icon({ type }){
  if(type === 'IN'){
    return (
      <svg className="w-6 h-6 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 11V3m0 0L7 8m5-5 5 5M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
    );
  }
  if(type === 'PAUSE'){
    return (
      <svg className="w-6 h-6 mr-2" fill="currentColor" viewBox="0 0 20 20"><path d="M6 4h2v12H6V4zm6 0h2v12h-2V4z"/></svg>
    );
  }
  if(type === 'RETURN'){
    return (
      <svg className="w-6 h-6 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 10h11a4 4 0 110 8h-1M21 14v6M21 14l-3 3M21 14l-3-3"></path></svg>
    );
  }
  // OUT
  return (
    <svg className="w-6 h-6 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a2 2 0 01-2 2H5a2 2 0 01-2-2V7a2 2 0 012-2h6a2 2 0 012 2v1"></path></svg>
  );
}

export default function ClockButton({ type = 'IN', label = 'Entrada', onClick, disabled = false }){
  const base = 'px-6 py-4 rounded-lg shadow-md inline-flex items-center font-semibold text-lg focus:outline-none transition-colors';

  const styles = {
    IN: 'bg-green-500 hover:bg-green-600 text-white',
    PAUSE: 'bg-yellow-400 hover:bg-yellow-500 text-black',
    RETURN: 'bg-green-400 hover:bg-green-500 text-white',
    OUT: 'bg-red-500 hover:bg-red-600 text-white'
  };

  const cls = `${base} ${styles[type] || styles.IN} ${disabled ? 'opacity-50 cursor-not-allowed hover:bg-none' : ''}`;

  return (
    <button aria-label={label} onClick={onClick} disabled={disabled} className={cls}>
      <Icon type={type} />
      <span>{label}</span>
    </button>
  );
}
