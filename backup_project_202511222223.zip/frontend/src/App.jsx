import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Login from './pages/Login';
import Clock from './pages/Clock';
import History from './pages/History';
import Admin from './pages/Admin';
import Layout from './components/Layout';
import PrivateRoute from './components/PrivateRoute';
import AdminRoute from './components/AdminRoute';

export default function App(){
  return (
    <Routes>
      <Route path="/login" element={<Login/>} />

      <Route element={<PrivateRoute/>}>
        <Route element={<Layout/>}>
          <Route path="/" element={<Clock/>} />
          <Route path="/history" element={<History/>} />
        </Route>

        <Route element={<AdminRoute/>}>
          <Route path="/admin" element={<Admin/>} />
        </Route>
      </Route>
    </Routes>
  );
}
import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Login from './pages/Login';
import Clock from './pages/Clock';
import History from './pages/History';
import Layout from './components/Layout';
import PrivateRoute from './components/PrivateRoute';

export default function App(){
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route element={<PrivateRoute />}>
        <Route element={<Layout />}>
          <Route path="/" element={<Clock />} />
          <Route path="/history" element={<History />} />
        </Route>
      </Route>
    </Routes>
  );
}
